/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var bounds = 
    /* color: #1980a3 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-76.79698153671495, 36.10863373751046],
          [-76.79698153671495, 35.98844039082434],
          [-76.52747317489855, 35.98844039082434],
          [-76.52747317489855, 36.10863373751046]]], null, false);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var assets = require('users/gena/packages:assets')
var animation = require('users/gena/packages:animation')
var charting = require('users/gena/packages:charting')

// zoom-in to our area of interest
Map.centerObject(bounds)

// get images
var images = assets.getImages(bounds.centroid(1), {
  missions: [/*'S2',*/ 'L8'],
  filter: ee.Filter.and(
    ee.Filter.date('2020-01-01', '2021-01-01'),
    ee.Filter.contains('.geo', bounds)
  )
})
print(images.size())

// filter to mostly cloud-free images
images = assets.getMostlyCleanImages(images, bounds, { scale: Map.getScale() * 10})
print(images.size())

images = images.sort('system:time_start')

images = images.map(function(i) { 
  return i
    .set({ label: i.date().format('YYYY-MM-dd') })
    .clip(bounds)
})

// animate
animation.animate(images, {
  vis: { min: 0.05, max: 0.3, bands: ['red', 'green', 'blue'] },
  // vis: { min: 0.05, max: 0.5, bands: ['swir', 'nir', 'green'] },
  label: 'label'
})


