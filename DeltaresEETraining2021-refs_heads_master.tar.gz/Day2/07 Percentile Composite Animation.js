/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var images = ee.ImageCollection("LANDSAT/LC08/C01/T1_RT_TOA");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
Map.setOptions('SATELLITE')

images = images.filterBounds(Map.getCenter())
print('Image count: ', images.size())

var percentiles = ee.List.sequence({
  start: 0, 
  end: 100, 
  step: 10
})

var bandNames = images.first().bandNames()

var composites = percentiles.map(function(p) {
  return images.reduce(ee.Reducer.percentile([p])).rename(bandNames)
})

var animation = require('users/gena/packages:animation')

animation.animate(composites, {
  vis: { min: 0.05, max: 0.5, bands: ['B6', 'B5', 'B3'] }
})