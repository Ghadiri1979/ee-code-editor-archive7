/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = /* color: #d63000 */ee.Geometry.Point([-82.30383393199905, 33.712275669109246]),
    landsat8_TOA = ee.ImageCollection("LANDSAT/LC08/C01/T1_RT_TOA"),
    landsat8_SR = ee.ImageCollection("LANDSAT/LC08/C01/T1_SR");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var imageTOA = landsat8_TOA
  .filterDate('2019-01-01', '2019-02-01')
  .filterBounds(geometry)
  .first()
  
var vis = { bands: ['B4', 'B3', 'B2'], min: 0.04, max: 0.2 }
Map.addLayer(imageTOA, vis, 'image TOA')

var visFalse = { bands: ['B6', 'B5', 'B3'], min: 0.0, max: 0.25 }
Map.addLayer(imageTOA, visFalse, 'image TOA False')

var imageSR = landsat8_SR
  .filterDate('2019-01-01', '2019-02-01')
  .filterBounds(geometry)
  .first()
  .multiply(0.0001)
  
var vis = { bands: ['B4', 'B3', 'B2'], min: 0.0, max: 0.15 }
Map.addLayer(imageSR, vis, 'image SR')  

var visFalse = { bands: ['B6', 'B5', 'B3'], min: 0.0, max: 0.25 }
Map.addLayer(imageSR, visFalse, 'image SR False')
