/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var s2_level1 = ee.ImageCollection("COPERNICUS/S2");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
Map.setCenter(-8.0861, 39.9492,13)

// Filter the Sentinel-2 Top Of Atmosphere image collection
s2_level1 = s2_level1.filterBounds(ee.Geometry(Map.getBounds(true)))
            .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
            .limit(20);

// Visualize in RGB
Map.addLayer(s2_level1, { min: 0, max: 3000, bands: [ 'B4' , 'B3' , 'B2' ] }, 'True Colour')

// Visualize in False color
Map.addLayer(s2_level1, { min: 0, max: 3000, bands: [ 'B6' , 'B4' , 'B3' ] }, 'False Colour')

/***
 * Task: Load the Sentinel-2 Level 2 Surface Reflectance dataset and 
 *       visualize them in RGB and false colour.
***/
function exercise1() {
  // type your solution here
}







































function solution1() {
  var s2_level2 = ee.ImageCollection("COPERNICUS/S2_SR");
  s2_level2 = s2_level2.filterBounds(ee.Geometry(Map.getBounds(true)))
            .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 0.1)
            .limit(20);
  print(s2_level2)
  Map.addLayer(s2_level2, { min: 0, max: 2000, bands: [ 'B4', 'B3', 'B2' ] }, 'RGB' )
  Map.addLayer(s2_level2, { min: 0, max: 2000, bands: [ 'B6', 'B4', 'B3' ] }, 'FalseColour' )
  
}