/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var dem = ee.Image("JAXA/ALOS/AW3D30/V2_2");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
 var palettes = require('users/gena/packages:palettes')
 
 
 Map.addLayer(dem.select('AVE_DSM'), { palette: palettes.colorbrewer.BrBG[7].reverse(), min:0, max: 1500 })
 
 // add a link to dem styling examples
 print('https://github.com/gee-community/ee-palettes')
 
 
 