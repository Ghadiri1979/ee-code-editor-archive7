/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var cdl = ee.ImageCollection("USDA/NASS/CDL"),
    geometry = /* color: #d63000 */ee.Geometry.MultiPolygon(
        [[[[-121.92626953125, 38.57823196583313],
           [-121.63787841796875, 38.642617906345265],
           [-121.63238525390625, 38.99570671505043],
           [-121.96197509765625, 39.02771884021161]]],
         [[[-121.59393310546875, 38.19502155795575],
           [-121.58843994140625, 37.931200459333716],
           [-121.409912109375, 37.95286091815649],
           [-121.4813232421875, 38.16911413556086]]],
         [[[-120.750732421875, 37.09900294387622],
           [-120.63262939453125, 36.91915611148194],
           [-120.49530029296875, 36.97622678464096],
           [-120.6573486328125, 37.10995544464346]]]]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// Load Sentinel-2 TOA reflectance data.
var s2 = ee.ImageCollection('COPERNICUS/S2');

// Function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60');

  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();

  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));

  // Return the masked and scaled data.
  return image.updateMask(mask).divide(10000);
}

// Map the cloud masking function over one year of data
var s2filtered = s2.filterDate('2016-01-01', '2016-12-31')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds)
                  .select('B.*');

var composite = s2filtered.median();

// Display the results.
Map.addLayer(composite, {bands: ['B3', 'B2', 'B1'], min: 0, max: 0.3}, 'composite', false);

// Load the CDL image for 2016.  This is the training data.
var cdl2016 = ee.Image(cdl.filterDate('2016-01-01', '2016-12-13').first());

// We only want the first few crop types.
cdl2016 = cdl2016.select('cropland');
cdl2016 = cdl2016.updateMask(cdl2016.lte(6));
Map.addLayer(cdl2016, {}, 'cdl2016');

// Take a stratified sample.
var sample = cdl2016.addBands(composite).stratifiedSample({
  numPoints: 1000, 
  classBand: 'cropland', 
  region: geometry, 
  scale: 10, 
  seed: 1,
  tileScale: 8
});

var histogram = sample.reduceColumns({
  reducer: ee.Reducer.frequencyHistogram(), 
  selectors: ['cropland']
});
// print(histogram); // OK


// Partition the training.
sample = sample.randomColumn({ seed: 1 });
var training = sample.filter(ee.Filter.lt('random', 0.7));
var validation = sample.filter(ee.Filter.gte('random', 0.7));

var classifier = ee.Classifier.smileRandomForest(10)
    .train({
      features: training, 
      classProperty: 'cropland', 
      inputProperties: composite.bandNames()
    });

var classified = composite.classify(classifier);
Map.addLayer(classified, {min: 0, max: 6}, 'classified', false);

var trainAccuracy = classifier.confusionMatrix().accuracy();
print('trainAccuracy', trainAccuracy); // 0.9701408450704225

var testAccuracy = validation
    .classify(classifier)
    .errorMatrix('cropland', 'classification')
    .accuracy();
print('testAccuracy', testAccuracy); // 0.8068965517241379

// Parameter tuning. 
var numTrees = ee.List.sequence(5, 50, 5);

var accuracies = numTrees.map(function(t) {
  var classifier = ee.Classifier.smileRandomForest(t)
    .train({
      features: training, 
      classProperty: 'cropland', 
      inputProperties: composite.bandNames()
    });
  return validation
    .classify(classifier)
    .errorMatrix('cropland', 'classification')
    .accuracy();
});

print(ui.Chart.array.values({
  array: ee.Array(accuracies), 
  axis: 0, 
  xLabels: numTrees
}));


