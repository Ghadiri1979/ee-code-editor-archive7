// see https://github.com/gee-community/ee-palettes
var palettes = require('users/gena/packages:palettes')

Map.setOptions('SATELLITE')

var images = ee.ImageCollection("LANDSAT/LC08/C01/T1_RT_TOA");

images = images
  .filterDate('2013-04-01', '2013-05-01')

print('Image count: ', images.size())

var count = images.select('B10').reduce(ee.Reducer.count())
print(count)

Map.addLayer(count, { min: 0, max: 5, palette: palettes.cb.RdYlGn[7] }, 'count')

// Task: add a new layer showing image count for the same month in 2020

// Task: increase date range ... and wait :-) ...

