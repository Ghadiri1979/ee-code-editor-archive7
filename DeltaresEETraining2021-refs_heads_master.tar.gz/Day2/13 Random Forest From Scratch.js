/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var imageCollection = ee.ImageCollection("USDA/NAIP/DOQQ"),
    soil = /* color: #d63000 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[-92.96240007933801, 31.874101370872328],
                  [-92.96268975791162, 31.87416514812918],
                  [-92.96268975791162, 31.87402848252475]]]),
            {
              "class": 0,
              "system:index": "0"
            })]),
    water = /* color: #98ff00 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[-92.95911705550378, 31.87124957127152],
                  [-92.95845186766809, 31.87150468792934],
                  [-92.9586879020614, 31.871750692609066],
                  [-92.95955693778222, 31.871577578273268]]]),
            {
              "class": 1,
              "system:index": "0"
            })]),
    vegetation = /* color: #0b4a8b */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[-92.96540415343469, 31.87276203828147],
                  [-92.965640187828, 31.87308092875931],
                  [-92.96594059523767, 31.8731173733151],
                  [-92.96572601851648, 31.872825816465337]]]),
            {
              "class": 2,
              "system:index": "0"
            })]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// 1. machine learning: (supervised classification ...)

// 2. RF
var image = imageCollection.filterDate('2019-01-01', '2020-01-01').mosaic()
Map.addLayer(image, {bands: ['N', 'R', 'G']})

// merge labels
var labels = soil.merge(vegetation).merge(water)

// generate samples
var samples = image.sampleRegions({
  collection: labels, 
  scale: 1, 
  geometries: true
})

print(samples.first())

print(ui.Chart.feature.histogram(samples, 'class'))

Map.addLayer(samples)

// train classifier
var classifier = ee.Classifier.smileRandomForest({
  numberOfTrees: 15, 
  seed: 42 // explain this
})

classifier = classifier.train({
  features: samples, 
  classProperty: 'class'
})

// classify map
var classifiedImage = image.addBands(dem).classify(classifier)

Map.addLayer(classifiedImage.randomVisualizer())

// 3. error analysis
print(classifier.confusionMatrix())
print(classifier.confusionMatrix().accuracy())

// 3.1 error analysis using independent test set


// 4. feature engineering
// add DEM slope


// 5. imbalanced datasets, stratified sampling - put into a more advanced example


// ...

