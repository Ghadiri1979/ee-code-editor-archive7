/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([27.743653290811423, 43.17612508036023]),
    dem = ee.Image("JAXA/ALOS/AW3D30/V2_2"),
    labelsWater = 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[27.803608183259122, 43.19433258107949],
          [27.796055082673185, 43.1953337519171],
          [27.791248564118497, 43.194082285803674],
          [27.789360288972013, 43.18845037069883],
          [27.797771696442716, 43.18820005129873]]]),
    labelsSoil = 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[27.803327142115243, 43.208097959794706],
          [27.800323068018564, 43.21028750559632],
          [27.79766231667579, 43.211726307183554],
          [27.796117364283212, 43.209912160469635],
          [27.79740482461036, 43.20778516112105],
          [27.799550591822275, 43.20640882790073],
          [27.80341297280372, 43.20534527641514]]]),
    labelsVegetation = 
    /* color: #ffc82d */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[27.779251633997568, 43.20568936863077],
          [27.779251633997568, 43.207472360843354],
          [27.77792125832618, 43.209036346191255],
          [27.773758469935068, 43.2085984343361],
          [27.77221351754249, 43.207096998392736],
          [27.774530946131357, 43.20631498586846],
          [27.77719169747413, 43.20537655760587]]]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
Map.setOptions('HYBRID')

var features = ee.FeatureCollection([
    ee.Feature(labelsWater, { 'class': 0, name: 'water' }),
    ee.Feature(labelsSoil, { 'class': 1, name: 'soil' }),
    ee.Feature(labelsVegetation, { 'class': 2, name: 'vegetation' }),
])
// print(features)
Map.addLayer(features)


// let's turn our features into an image
var featuresImage = features.reduceToImage(['class'], ee.Reducer.first())

// image
var image = ee.ImageCollection('COPERNICUS/S2')
  .filterBounds(geometry)
  .first()
  
Map.addLayer(image, { min: 500, max: 3500, bands: ['B12', 'B8', 'B4'] }, 'false')
Map.addLayer(image, { min: 500, max: 3500, bands: ['B4', 'B3', 'B2'] }, 'true')
Map.addLayer(featuresImage.randomVisualizer(), {}, 'labels')

image = image.addBands(featuresImage.rename('label'))

var region = features.geometry()
var training = image.sample({
  region: region, 
  scale: 10, 
  numPixels: 1000, 
  geometries: true
})

print(training)

Map.addLayer(training.style({ color: 'white', pointSize: 2, width: 0 }), {}, 'training points')


// TODO: split your training features into (train, validate, test)

// let's train a classifier

var classifier = ee.Classifier.smileRandomForest(15)

classifier = classifier.train(training, 'label')

// check training accuracy
var confusionMatrix = classifier.confusionMatrix()
print(confusionMatrix)

var accuracy = confusionMatrix.accuracy()
print(accuracy)

// let's classify our satellite image
var landuse = image.classify(classifier)

Map.addLayer(landuse.randomVisualizer(), {}, 'landuse map (results)', true, 0.5)