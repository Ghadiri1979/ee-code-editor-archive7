Map.setCenter(4.381442070007324, 51.98525016185232, 12); // Delft

var image = ee.Image('LANDSAT/LC8_L1T_TOA/LC81980242014068LGN00');

var vis = {min:0.05, max:0.3, gamma: 1.3, bands: [ 'B4', 'B3', 'B2' ]};

Map.addLayer(image, vis, 'RGB');

Map.addLayer(image.normalizedDifference(['B5', 'B4']), { min: -1, max: 1 }, 'NDVI raw')


/***
 * Task: Threshold NDVI to mark vegetated areas. What do you think the value should be?
*/
function exercise1() {
  // type your solution here
}

/***
 * Task: Map NDVI over an image collection
*/
function exercise2() {
  // type your solution here
}











































// Solution

function solution1() {
  var ndvi = image.normalizedDifference(['B5', 'B4'])
  Map.addLayer(ndvi.mask(ndvi.gt(0.5)), { min: 0.5, max: 1}, 'NDVI > 0.5')
}

function solution2() {
  var  l8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA')
            .filterDate('2019-01-01', '2020-01-01')
            .filterBounds(Map.getCenter())
            .filterMetadata('CLOUD_COVER', 'less_than', 20)
  function addNDVI(image) {
    return image.normalizedDifference(['B5', 'B4'])
  }
  var NDVI = l8.map(addNDVI)
  Map.addLayer(NDVI.median(), {palette: '5050FF, 000000, 00FF00', min:-0.5, max:0.5}, 'NDVI median', false);

  
}