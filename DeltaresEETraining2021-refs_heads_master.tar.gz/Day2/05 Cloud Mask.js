/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var images = ee.ImageCollection("LANDSAT/LC08/C01/T1_RT_TOA");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
Map.setOptions('SATELLITE')

images = images.filterBounds(Map.getCenter())
print('Image count: ', images.size())

images = images.filter(ee.Filter.lt('CLOUD_COVER', 20))
print('Image count after filtering: ', images.size())


images = images.map(function(image) {
  image = ee.Algorithms.Landsat.simpleCloudScore(image)
  
  var cloud = image.select('cloud').divide(100)
  var mask = ee.Image(1).subtract(cloud)
  
  return image.updateMask(mask)
})

var animation = require('users/gena/packages:animation')

animation.animate(images, {
  vis: { min: 0.05, max: 0.5, bands: ['B6', 'B5', 'B3'] }
})