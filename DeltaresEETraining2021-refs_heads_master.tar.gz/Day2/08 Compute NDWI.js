/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var l8 = ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA"),
    geometry = /* color: #d63000 */ee.Geometry.Point([110.89462280273438, -7.901810703812147]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
Map.centerObject(geometry, 12)

var image = ee.Image(l8
  .filterBounds(Map.getCenter())
  .filterMetadata('CLOUD_COVER', 'less_than', 15)
  .select(['B6','B5','B3'])
  .toList(1, 10).get(0))
  
Map.addLayer(image, {min: 0.05, max: 0.5}, 'landsat 8')  

// add NDWI masked values
var ndwi = image.normalizedDifference(['B3', 'B6'])
Map.addLayer(ndwi, { min: -1, max: 1 }, 'NDWI raw')
Map.addLayer(ndwi.mask(ndwi), {palette:['000055', '0000ff'], opacity: 0.5}, 'water mask')

// show water edge
var edge = ee.Algorithms.CannyEdgeDetector(ndwi, 0.99)
Map.addLayer(edge.mask(edge), {palette:['ffffff']}, 'reservoir edge')


// Exercises
/***
 * Task: Calculate the NDWI of an image using add/subtract/divid methods instead of normalizedDifference.
 *       The formula for NDWI: (Green - NIR) / (Green + NIR)
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Generate a water mask by using threshold of NDWI == 0, NDWI == 0.05, NDWI == -0.05
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Generate histogram of NDWI along Canny Edge
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}

exercise1()

exercise2()

exercise3()




























function solution1() {
  // Watch the brackets and order of operations!
  var ndwi2 = (image.select('B3').subtract(image.select('B6'))).divide(image.select('B3').add(image.select('B6')))
  Map.addLayer(ndwi2, { palette: [ '#e0f3db', '#1c9099' ] }, 'ndwi')
}


function solution2() {
  Map.addLayer( ndwi.gt(0) , {}, 'Mask == 0')
  Map.addLayer( ndwi.gt(0.05), {}, 'Mask == 0.05' )
  Map.addLayer( ndwi.lt(-0.05), {}, 'Mask == -0.05')
  
}

function solution3() {
  print(ui.Chart.image.histogram({
  image: ndwi.mask(edge), 
  region: geometry.buffer(100 * Map.getScale()), 
  scale: 30, 
  maxBuckets: 100
}))
}