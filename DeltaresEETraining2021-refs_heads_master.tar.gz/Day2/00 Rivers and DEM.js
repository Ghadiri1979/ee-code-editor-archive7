/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var rivers = ee.FeatureCollection("WWF/HydroSHEDS/v1/FreeFlowingRivers"),
    geometry = 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[29.150171461939607, 52.10136515632273],
          [29.150171461939607, 47.84072792865192],
          [34.84108943068961, 47.84072792865192],
          [34.84108943068961, 52.10136515632273]]], null, false);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var largerRivers = rivers.filter(ee.Filter.gt('DIS_AV_CMS', 100))
Map.addLayer(largerRivers.style({ color: 'blue', width: 5 }), {}, 'larger rivers (Q > 100')

var riversInView = largerRivers.filterBounds(geometry)
Map.addLayer(riversInView, {color: 'red'}, 'rivers within geometry')

var images = ee.ImageCollection('COPERNICUS/S2')
  .filterBounds(riversInView.geometry()) 
  .filterDate('2021-01-01', '2021-03-01')
  .select(['B12', 'B8', 'B3'] )

Map.addLayer(images, {}, 'image stack')
Map.addLayer(images.geometry(), {}, 'image stack bounds')
  
var image = images.reduce(ee.Reducer.percentile([5]))  
  
var buffer = riversInView.geometry().buffer(25000)
Map.addLayer(buffer, {}, 'clip buffer')
  
Map.addLayer(image.clip(buffer), { min: 500, max: 5000 }, 'final image')

Export.image.toDrive(image)
