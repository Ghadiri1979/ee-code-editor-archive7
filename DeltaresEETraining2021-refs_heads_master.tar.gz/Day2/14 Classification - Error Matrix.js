/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var other = 
    /* color: #8b8b8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[68.33029607346306, 40.436836585304],
                  [68.32239965012322, 40.41226892890758],
                  [68.36462834885369, 40.39815153655309],
                  [68.38145116379509, 40.427690102200714]]]),
            {
              "class": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[68.58916142990837, 40.356828087683276],
                  [68.60564092209587, 40.382985113510436],
                  [68.57542851975212, 40.39762861330729],
                  [68.5579190593029, 40.369646298841744]]]),
            {
              "class": 0,
              "system:index": "1"
            })]),
    water = 
    /* color: #039bd6 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[68.47701009521482, 40.37625284875486],
                  [68.46293386230467, 40.34433672675909],
                  [68.50241597900389, 40.32392341963745],
                  [68.49932607421873, 40.377037481079554]]]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[68.54680833374647, 40.562977354626106],
                  [68.5979634240785, 40.57653859101789],
                  [68.5543614343324, 40.59843939802014],
                  [68.51934251343397, 40.59426836868247]]]),
            {
              "class": 1,
              "system:index": "1"
            })]),
    sedimentedWater = 
    /* color: #c28ad9 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[68.42302259216306, 40.36373018821395],
                  [68.4230655075073, 40.36288000159124],
                  [68.42581208953855, 40.362978100594944],
                  [68.43212064514158, 40.36232410454034],
                  [68.43177732238767, 40.36314159861722],
                  [68.42572625885008, 40.364024481085096]]]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[68.50671086596157, 40.38001367133905],
                  [68.50739751146938, 40.376090591640896],
                  [68.51177487658168, 40.37720215408094],
                  [68.51177487658168, 40.38132131380863]]]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[68.46475047259167, 40.381878545845524],
                  [68.46526545672253, 40.38122473319158],
                  [68.47367686419324, 40.384362976059464],
                  [68.47110186123429, 40.38547447635131]]]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[68.5181834948591, 40.448401101178064],
                  [68.5192992938093, 40.444482006445114],
                  [68.52753903990305, 40.441215919604915],
                  [68.52247502928293, 40.43540189239964],
                  [68.52771070128, 40.43468326985645],
                  [68.53500630980051, 40.44520052425343]]]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[68.42166718994764, 40.341125149928224],
                  [68.42209634339002, 40.33458278428956],
                  [68.43248185669569, 40.32745088315633],
                  [68.4335118249574, 40.342237288996216]]]),
            {
              "class": 2,
              "system:index": "4"
            })]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var image = ee.Image('COPERNICUS/S2_SR/20200504T061629_20200504T062448_T42TVK');
// Sardoba reservoir, dam break on May 1, 2020
Map.setCenter(68.4801, 40.348, 12);
var aoi = Map.getBounds(true);

Map.addLayer(image, { min: 300, max: 3500, bands: ['B4', 'B3', 'B2'] }, 'RGB');
Map.addLayer(image, { min: 300, max: 3500, bands: ['B12', 'B8', 'B4'] }, 'SWIR2, NIR, Red');

Map.addLayer(image.select(['B3', 'B8']).normalizedDifference().selfMask(), { min: 0, max: 1 }, 'NDWI');

var palette = ["#8b8b8b", "#039bd6", "#bb8b35"];

// merge feature collections
var classes = other.merge(water).merge(sedimentedWater);

// paint features to image
var property = 'class'
var classImage = ee.Image().int().paint(classes, 'class').rename(property);
Map.addLayer(classImage, {min:0, max:2, palette: palette}, 'Classes', false);

// add class image as band to S2 image
image = image.addBands(classImage)

// stratified sample of classes
var samples = image.stratifiedSample({
  numPoints: 100, 
  classBand: property, 
  region: aoi, 
  scale: 10,
  dropNulls: true,
  geometries: true
}).randomColumn('random');
Map.addLayer(samples, {}, 'samples', false)

// split features into 70% training, 30% testing
var split = 0.7;
var trainingPoints = samples.filter(ee.Filter.lt('random', split))
var testingPoints = samples.filter(ee.Filter.gte('random', split));

// classify image
var classifier = ee.Classifier.smileRandomForest({
  numberOfTrees: 10,
  seed: 42
})

// train classifier with training points
var trainedClassifier = classifier.train({
  features: trainingPoints,
  classProperty: property,
  inputProperties: image.bandNames()
})

// calculate training accuracy
var trainingAccuracy = trainedClassifier.confusionMatrix().accuracy();
print('training accuracy:', trainingAccuracy)

// classify image
var classifiedImage = image.classify(trainedClassifier);

// print error matrix
var errorMatrix = testingPoints
  .classify(trainedClassifier)
  .errorMatrix(property, 'classification');
print('Error matrix:', errorMatrix)

// print testing accuracy
print('Testing accuracy:', errorMatrix.accuracy())

// display classified image
Map.addLayer(classifiedImage, {min:0, max:2, palette: palette}, 'Classified Image')

// TODO: can you improve classification accuracy with more sample areas defined?
// What about changing other parameters?
// TODO: add another class. e.g. urban area