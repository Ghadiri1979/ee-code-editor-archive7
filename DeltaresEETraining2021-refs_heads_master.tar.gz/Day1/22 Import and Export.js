/***
 * Task: Import a georeferenced raster image into your Assets and add it to the Map
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Import a shapefile into your Assets and add it to the Map
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Write code to export SRTM DEM to GDrive for France at 1000m resolution
 * 
 * User Guide: https://developers.google.com/earth-engine/guides/exporting
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()

exercise3()


































/***
 * Task: Import a georeferenced raster image into your Assets and add it to the Map
 */
function solution1() {
}

/***
 * Task: Import a shapefile into your Assets and add it to the Map
 */
function solution2() {
}

/***
 * Task: Write code to export SRTM DEM to GDrive for France at 1000m resolution
 * 
 * User Guide: https://developers.google.com/earth-engine/guides/exporting
 */
function solution3() {
  var srtm = ee.Image("CGIAR/SRTM90_V4")
  
  var countries = ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017")
  var france = countries.filter(ee.Filter.eq('country_na', 'France'))
  
  Map.addLayer(france)
  Map.centerObject(france)
  
  var bounds = france.geometry().bounds()
  Map.addLayer(bounds)
  
  Export.image.toDrive({
    image: srtm, 
    description: 'srtm-france', 
    fileNamePrefix: 'srtm-france', 
    region: bounds, 
    scale: 1000
  })
}
