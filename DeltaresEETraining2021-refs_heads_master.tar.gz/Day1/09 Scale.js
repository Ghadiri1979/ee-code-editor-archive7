print('https://developers.google.com/earth-engine/guides/scale')

/***
 * Task: Check the user guide link provided above to understand how scale works in EE
 */
function exercise1() {
}

/***
 * Task: Print native scale used to store different bands in the image below
 * 
 * Tip: you have to query image projection and check Docs for ee.Projection on how to optain image scale
 */
function exercise2() {
  var image = ee.Image('LANDSAT/LC08/C01/T1/LC08_044034_20140318')
  
  // this is how we can get band names from an image
  var bandNames = image.bandNames().getInfo()
  
  for(var i=0; i<bandNames.length; i++) {
    // ... TYPE YOUR SOLUTION HERE
  }
}

exercise1()

exercise2()















































/***
 * Task: Check the user guide link provided above to understand how scale works in EE
 */
function solution1() {
}

/***
 * Task: Print native scale used to store different bands in the image below
 * 
 * Tip: you have to query image projection and check Docs for ee.Projection on how to optain image scale
 */
function solution2() {
  var image = ee.Image('LANDSAT/LC08/C01/T1/LC08_044034_20140318')
  
  // this is how we can get band names from an image
  var bandNames = image.bandNames().getInfo()
  
  for(var i=0; i<bandNames.length; i++) {
    // ... TYPE YOUR SOLUTION HERE
    print(bandNames[i], image.select(bandNames[i]).projection().nominalScale())
  }
}


