// Visualizing data is just as important as analysing it. Earth engine comes with its own charting capabilities under the ui.Chart() method.

// As an example, let's define a list of values that we want to plot.
var values = [1, 3, 2, 5, 6]

// A very simple scatter plot can be made just by the following line of code.
var chart1 = ui.Chart.array.values({ array: values, axis: 0 })

print(chart1);

// ui.Chart has a variety of options you can define. We list a few below, feel free to play around with them and see what happens.
print('https://developers.google.com/earth-engine/guides/charts_overview')


/***
 * Task: create and print a new chart using "values" variable defined above, change chart type to ColumnChart
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: create and print a new chart using "values" variable defined above, change point size to 3 and line width to 1
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: show a red trendline in addition to the points
 * 
 * Tip: use Google Chart User Guide for more advanced styling: https://developers.google.com/chart/interactive/docs/gallery/trendlines#correlations
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()

exercise3()
























































/***
 * Task: create and print a new chart using "values" variable defined above, change chart type to ColumnChart
 */
function solution1() {
  var chart = ui.Chart.array.values( { array: values, axis: 0 })
  
  chart = chart.setChartType('ColumnChart')
  
  print(chart)
}

/***
 * Task: create and print a new chart using "values" variable defined above, change point size to 3 and line width to 1
 */
function solution2() {
  var chart = ui.Chart.array.values( { array: values, axis: 0 })
  
  chart = chart.setOptions({
    pointSize: 3,
    lineWidth: 1
  })
  
  print(chart)
}

/***
 * Task: add a trendline to the chart series
 * 
 * Tip: use Google Chart User Guide for more advanced styling.
 */
function solution3() {
  var chart = ui.Chart.array.values( { array: values, axis: 0 })
  
  chart = chart.setOptions({
    trendlines: {
      0: {
        type: 'linear',
        color: 'red',
        lineWidth: 1
      }
    }    
  })
  
  print(chart)
}
