/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var alos = ee.Image("JAXA/ALOS/AW3D30/V2_2"),
    srtm = ee.Image("CGIAR/SRTM90_V4");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var image = ee.ImageCollection("COPERNICUS/S2_SR").first()
Map.centerObject(image)

Map.addLayer(image, { min: 0, max: 3000, bands: ['B4', 'B3', 'B2'] }, 'image')

/***
 * Task: Get the min/max/mean value of the red band of the image defined above using scale = 150m
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Use srtm image and compute mean elevation value for the extent of the image defined above using scale = 100m
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Compute difference between ALOS and SRTM dem and show a histograms of elevation values and differences for the extent of the above image
 */
function exercise3() {
  alos = alos.select('AVE_DSM') // ALOS dem has multiple bands

  // ... TYPE YOUR SOLUTION HERE
}

exercise1()

exercise2()

exercise3()








































/***
 * Task: Get the min/max/mean value of the red band of the image defined above using scale = 150m
 */
function solution1() {
  // ... TYPE YOUR SOLUTION HERE
  
  var reducer = ee.Reducer.minMax().combine({ 
    reducer2: ee.Reducer.mean(), 
    sharedInputs: true
  })
  
  var stat = image.reduceRegion({ 
    reducer: reducer, 
    geometry: image.geometry().bounds(), 
    scale: 500
  })
  
  print(stat)
}

/***
 * Task: Use srtm image and compute mean elevation value for the extent of the image defined above using scale = 100m
 */
function solution2() {
  // ... TYPE YOUR SOLUTION HERE

  var meanElevation = srtm.reduceRegion({
    reducer: ee.Reducer.mean(), 
    geometry: image.geometry().bounds(), 
    scale: 100
  })
  
  print('SRTM mean elevation for S2 image: ', meanElevation)
}

/***
 * Task: Compute difference between ALOS and SRTM dem and show a histograms of elevation values and differences for the extent of the above image
 */
function solution3() {
  alos = alos.select('AVE_DSM') // ALOS dem has multiple bands

  // ... TYPE YOUR SOLUTION HERE
  
  var region = image.geometry()
  
  // show a histogram of values over region
  var scale = 100
  print('ALOS values over the image extent: ', ui.Chart.image.histogram(alos, region, scale))
  
  // compute differences between dems and add to the Map
  var diff = alos.subtract(srtm)
  Map.addLayer(diff, { min: -20, max: 20, palette: ['red', 'white', 'blue' ] }, 'diff')
  
  // show histogram of differences over our image
  print(ui.Chart.image.histogram(diff, region, scale))
}
