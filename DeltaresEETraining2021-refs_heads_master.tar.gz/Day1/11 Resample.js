var image = ee.Image('LANDSAT/LC08/C01/T1/LC08_044034_20140318').select('B4');
var visparams = {min: 5000, max: 10000}
Map.setCenter(-122.19, 37.483, 14)

// By default, Earth Engine uses the nearest-neighbour method during
// reprojections. However, you can specify as well if you prefer to use another
// method. EE can use both bilinear or bicubic resampling methods.

Map.addLayer(image, visparams, 'original')

// To illustrate the differences, let's look at each of
// the resampling methods.

// Nearest Neighbour
var nn = image.reproject({crs:'EPSG:4326', scale: 30
})

// Bilinear interpolation
var bilinear = image.resample('bilinear');

// Bicubic interpolation
var bicubic = image.resample('bicubic');

Map.addLayer(nn, visparams, 'nearest neighbour')
Map.addLayer(bilinear, visparams, 'bilinear');
Map.addLayer(bicubic, visparams, 'bicubic');

// Toggle with the Layers controls to see the differences.

/***
 * Task: Zoom in to the pixel level for the above image and check image values using Inspector
 */

// NO CODING FOR THIS EXERCICE

