/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = /* color: #d63000 */ee.Geometry.Point([4.4558646685746695, 51.89996864658499]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// Earth Engine has it's own type to represent date and time called ee.Date

// Users can use that type to create date/time objects:
var t = ee.Date('2020-01-01') // EE date/time
print(t) 

// Objects like Features or Images can have date/time associated with them and by convention, this is stored in system:time_start property
// For example, let's query that property for the first Sentinel-2 image
var image = ee.ImageCollection('COPERNICUS/S2').first()
var t = image.get('system:time_start')

print('Time of the first Sentinel-2 image: ', t)

// ... hmm, that property is not a date/time, in fact, it's a time stamp represented in milliseconds since 1970-01-01
// we can convert it to the ee.Date object by simply wrapping like this:
t = ee.Date(t)

print(t) // now we can read the actual date time in the Console

// However, this can be done faster by using ee.Image.date() method, for every image which has system:time_start associated, for eample:
print(image.date())


// NO EXERCISES HERE