print('https://developers.google.com/earth-engine/tutorials/tutorial_js_01')

/***
 * Task: play around with the print() function, copy/paste/run scripts from user guide link below.
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: print current date using JavaScript API
 * 
 * Tip: Google it!
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
  * Task: Define a JavaScript dictionary consisting of (foo, 1), (bar, 'string')  key/value pairs
  */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}


// here we call our functions

exercise1()

exercise2()

exercise3()




// if you stuck - scroll down for a solution













































/***
 * Task: play around with the print() function, copy/paste/run scripts from user guide link below.
 */
function solution1() {
  print('Nothing to solve here')
}

/***
 * Task: print current date using JavaScript API
 * 
 * Tip: Google it!
 */
function solution2() {
  var t = Date()
  print('Current date and time is: ', t)
}

/***
 * Task: Define a JavaScript dictionary consisting of (foo, 1), (bar, 'string')  key/value pairs
 */
function solution3() {
  // Use curly brackets {} to make a dictionary of key:value pairs.
  var object = {
    foo: 1,
    bar: 'string'
  };
  
  print('Dictionary:', object);
  
  // Access dictionary items using square brackets.
  print('Print foo:', object['foo']);
  
  // Access dictionary items using dot notation.
  print('Print bar:', object.bar);
}
