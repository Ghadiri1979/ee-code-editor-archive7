// Projections are specified by a Coordinate Reference System (CRS)
// How do you check the projection of individual images?
var image = ee.Image('LANDSAT/LC08/C01/T1/LC08_044034_20140318').select(0);

print('Projection information: ', image.projection());
print('Scale in meters:', image.projection().nominalScale());

// Normally, there is no need to specify a projection before you carry out
// your analyses. However, when combining different images that contain
// different projections, you might want to harmonize the CRS across the images.
// More detailed area calculations may also require reprojection to a native CRS
// eg, UTM zones.

// You can reproject images beforehand like below
var projection = 'EPSG:4326' // WGS84
image = image.reproject(projection)

// In some cases, when carrying out certain analyses (eg. reducers), you can also
// specify projections to harmonize the data treatment across all iamges.

// Further reading: https://developers.google.com/earth-engine/guides/projections


// NO EXERCICES HERE YET