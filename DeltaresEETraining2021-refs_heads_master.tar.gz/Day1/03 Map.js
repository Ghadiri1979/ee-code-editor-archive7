/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var elevation = ee.Image("USGS/SRTMGL1_003"),
    countries = ee.FeatureCollection("USDOS/LSIB/2017");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// The Map object in the API refers to the map display in the Code Editor. 

// For example, the following Map methods can be used to return the geographic region visible in the Code Editor, 
// as well as other parameters such as zoom or scale
print('Map bounds: ', Map.getBounds())
print('Map zoom: ', Map.getZoom())
print('Map scale: ', Map.getScale())

// Map API can be used to change location and zoom automatically
Map.setCenter({ lon: 0, lat: 25, zoom: 3 })

// Map is used to visualize vector or raster layers 
Map.addLayer(countries, { }, 'countries', false)

Map.addLayer(elevation, { min: 0, max: 3000 }, 'elevation', true, 0.5)

/***
 * Task: Discover documentation for Map methods listed above by checking Docs tab on the left side of the Code Editor (type Map in the filter box there).
 * Task: Click on Inspector tab on the upper right part of Code Editor and click at any point on the map to discover values of the added vector and raster layers
 * Task: Check Layers on the right and change styles of the elevation layer
 */
function exercise1() {
  // No coding is required for this exercice
}

/***
 * Task: change current map style to SATELLITE, HYBRID (satellite image + labels) or TERRAIN using API
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Search for Rennes, France in the search text box on top of Code Editor, get coordinates using Inspector and make map to jump
 * to the ripparian are south of Rennes at zoom level 
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()

exercise3()

















































/***
 * Task: Discover documentation for Map methods listed above by checking Docs tab on the left side of the Code Editor (type Map in the filter box there).
 * Task: Click on Inspector tab on the upper right part of Code Editor and click at any point on the map to discover values of the added vector and raster layers
 * Task: Check Layers on the right and change styles of the elevation layer
 */
function solution1() {
  // No coding is required for this exercice
}

/***
 * Task: change current map style to SATELLITE, HYBRID (satellite image + labels) or TERRAIN using API
 */
function solution2() {
  Map.setOptions('HYBRID')
}

/***
 * Task: Search for Rennes, France in the search text box on top of Code Editor, get coordinates using Inspector and make map to jump
 * to the ripparian are south of Rennes at zoom level 
 */
function solution3() {
  Map.setCenter(-1.751147, 48.090686, 16)
}


// solution1()
// solution2()
// solution3()