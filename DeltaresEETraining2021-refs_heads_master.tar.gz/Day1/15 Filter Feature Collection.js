/***
 * Task: Search for "free flowing rivers" dataset in Data Catalog, add rivers with the DIS_AV_CMS property > 10 styled with the line width = 2
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Search for countries dataset in Data Catalog, filter by Italy and add to Map
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()






























































/***
 * Task: Search for "free flowing rivers" dataset in Data Catalog, add rivers with the DIS_AV_CMS property > 10 styled with the line width = 2
 */
function solution1() {
  // ... TYPE YOUR SOLUTION HERE
  
  var rivers = ee.FeatureCollection("WWF/HydroSHEDS/v1/FreeFlowingRivers").filterBounds(Map.getBounds(true))

  Map.addLayer(rivers.filter(ee.Filter.gt('DIS_AV_CMS', 10)).style({ color: '0000ff', width: 2 } ), {}, 'larger rivers')
}

/***
 * Task: Search for countries dataset in Data Catalog, filter by Italy and add to Map
 */
function solution2() {
  // ... TYPE YOUR SOLUTION HERE
  
  var countries = ee.FeatureCollection("USDOS/LSIB/2017") 
  
  var italy = countries.filter(ee.Filter.eq('COUNTRY_NA', 'Italy'))
  Map.addLayer(italy)
  Map.centerObject(italy)
}
