/***
 * Task: Given a Sentinel-2 image defined in this exercice, make current map zoom-in to it, add it to the map, showing RGB bands (B4, B3, B2) vis (min, max) values set to (0.05, 0.25). 
 * Make sure to divide image by 10000 before adding to the Map.
 */
function exercise1() {
  // Let's try with a real satellite image this time. Inspect its bands, what are the individual bands named?
  var id = 'COPERNICUS/S2/20150706T105016_20150706T105351_T31UET'
  var image = ee.Image(id)
  print(image)

  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Visualize SRTM image using color palette copied from https://colorbrewer2.org/#type=diverging&scheme=BrBG&n=10 and (min, max) values set to (0, 1000)
 */
function exercise2() {
  var palette = ['#543005', '#8c510a', '#bf812d', '#dfc27d', '#f6e8c3', '#c7eae5', '#80cdc1', '#35978f', '#01665e', '#003c30'].reverse()
  
  var srtm = ee.Image("CGIAR/SRTM90_V4")
  
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Search for "Copernicus Global Land Cover Layers: CGLS-LC100 collection 3" image in data catalog and visualize 
 * discrete_classification band using palette stored in properties of that image and (min, max) values set to (0, 200) when adding image to the Map
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()

exercise3()














































/***
 * Task: Given a Sentinel-2 image defined in this exercice, make current map zoom-in to it, add it to the map, showing RGB bands (B4, B3, B2) vis (min, max) values set to (0.05, 0.25). 
 * Make sure to divide image by 10000 before adding to the Map.
 */
function solution1() {
  // Let's try with a real satellite image this time. Inspect its bands, what are the individual bands named?
  var id = 'COPERNICUS/S2/20150706T105016_20150706T105351_T31UET'
  var image = ee.Image(id)
  print(image)

  // ... TYPE YOUR SOLUTION HERE
  
  image = image.divide(10000)
  Map.centerObject(image)
  Map.addLayer(image, { min: 0.05, max: 0.25, bands: ['B4', 'B3', 'B2'] })
}

/***
 * Task: Visualize SRTM image using color palette copied from https://colorbrewer2.org/#type=diverging&scheme=BrBG&n=10 and (min, max) values set to (0, 1000)
 */
function solution2() {
  var palette = ['#543005', '#8c510a', '#bf812d', '#dfc27d', '#f6e8c3', '#c7eae5', '#80cdc1', '#35978f', '#01665e', '#003c30'].reverse()
  
  var srtm = ee.Image("CGIAR/SRTM90_V4")
  
  // ... TYPE YOUR SOLUTION HERE
  
  var srtmRGB = srtm.visualize({ min: 0, max: 1000, palette: palette })
  Map.addLayer(srtmRGB, {}, 'SRTM RGB')
}

/***
 * Task: Search for "Copernicus Global Land Cover Layers: CGLS-LC100 collection 3" image in data catalog and visualize 
 * discrete_classification band using palette stored in properties of that image and (min, max) values set to (0, 200) when adding image to the Map
 */
function solution3() {
  // ... TYPE YOUR SOLUTION HERE
  
  var image = ee.ImageCollection("COPERNICUS/Landcover/100m/Proba-V-C3/Global").first()
  var palette = image.get('discrete_classification_class_palette').getInfo()
  image = image.select('discrete_classification')
  print(image)
  
  Map.addLayer(image, { palette: palette, min: 0, max: 200 }, 'Copernicus Global Land Cover')
}
