// Trying to view every single image in a collection can become a hassle.
// Thanks to a growing community of EE users, convenient packages are written
// to help with analysis. Let's try creating an animation!
var animation = require('users/gena/packages:animation')  // Load animation package
var assets = require('users/gena/packages:assets')

// query images from multiple missions (Landsat and Sentinel-2) for a given point and dates
// note that only some bands are used, but renamed to readable band names

var pt = Map.getCenter()

var images = assets.getImages(pt, {
  missions: ['S2', 'L8', 'L7'],
  filter: ee.Filter.date('2020-04-01', '2020-06-01')
})

// sort by time
images = images.sort('system:time_start')

// set string label for every image
images = images.map(function(i) {
  return i.set({ label: i.date().format('YYYY-MM-dsd HH, ').cat(i.get('MISSION')) })
})

print('Number of images found: ', images.size())

// animate the images

animation.animate(images, {
  vis: { min: 0.05, max: 0.6 }, 
  maxFrames: 100, 
  label: 'label' 
})

// Repository of sources and examples: https://code.earthengine.google.com/?accept_repo=users/gena/packages


// No ecercices here, just to demonstrate one of the the ways to to animate images