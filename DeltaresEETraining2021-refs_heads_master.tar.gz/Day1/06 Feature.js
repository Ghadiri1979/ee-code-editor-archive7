print('https://developers.google.com/earth-engine/guides/features')

// add some dummy geometry
var geometry = Map.getCenter().buffer(Map.getScale() * 10)

// crate a new feature wrapping our new geometry
var feature = ee.Feature(geometry, { name: 'dummy feature', area: geometry.area() })
print(feature)
Map.addLayer(feature, {}, 'dummy feature')


/***
 * Task: Create a new feature by adding a new property height=100 to the "feature" defined above using ee.Feature API (see Docs)
 * Add resulting feture to the Map colored yellow and inspect it using Inspector.
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}


/***
 * Task: Create a new feature at with a point geometry at coordinates [0, 0] with the properties: { name: 'web mercator origin' }. 
 * Find these features on the Map (zoom out or using Map API)
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()
















































/***
 * Task: Create a new feature by adding a new property height=100 to the "feature" defined above using ee.Feature API (see Docs)
 * Add resulting feture to the Map colored yellow and inspect it using Inspector.
 */
function solution1() {
  var feature2 = feature.set({ height: 100 })
  Map.addLayer(feature2, { color: 'yellow' }, 'feature2')
}


/***
 * Task: Create a new feature at with a point geometry at coordinates [0, 0] with the properties: { name: 'web mercator origin' }. 
 * Find these features on the Map (zoom out or using Map API)
 */
function solution2() {
  var pointGeo = ee.Geometry.Point([0, 0], 'EPSG:4326')
  var pointWeb = ee.Geometry.Point([0, 0], 'EPSG:3857')
  
  Map.addLayer(pointGeo, { color: 'red'}, 'center geo')
  Map.addLayer(pointWeb, { color: 'blue'}, 'center web')
  
}