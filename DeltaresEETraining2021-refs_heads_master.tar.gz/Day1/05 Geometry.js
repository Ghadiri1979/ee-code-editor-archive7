/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var points = /* color: #98ff00 */ee.Geometry.MultiPoint(
        [[-17.28084150410505, 47.536396991676945],
         [-16.45686689473005, 47.77320742740854],
         [-15.995441113480053, 47.12686849146036]]),
    polylines = /* color: #0b4a8b */ee.Geometry.MultiLineString(
        [[[-15.907550488480053, 46.22231858740087],
          [-14.369464550980053, 46.72922577988802],
          [-14.237628613480053, 47.16422960173084],
          [-13.688312207230053, 47.47702654628347],
          [-12.721515332230053, 47.484451524490254],
          [-11.677814160355053, 47.699319526441435]],
         [[-14.808917675980053, 47.201564454585935],
          [-14.644122754105053, 47.736276583174124],
          [-14.039874707230053, 47.88384271791966],
          [-13.051105175980053, 47.94275178731011],
          [-12.974200879105053, 48.19969072690605]]]),
    polygon = /* color: #8f17c6 */ee.Geometry.Polygon(
        [[[-9.645343457230053, 47.372966657320916],
          [-9.678302441605053, 47.743664848917184],
          [-10.502277050980053, 47.72149690616195],
          [-10.996661816605053, 47.551229110791894],
          [-11.095538769730053, 47.27615539854213],
          [-10.963702832230053, 46.9021502832279]]]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// User Guide section about geometries
print('https://developers.google.com/earth-engine/guides/geometries')

// make sure the Map is centered on our geometries
var geometries = ee.FeatureCollection([points, polygon, polylines])
Map.centerObject(geometries)

/***
 * Task: Draw a new polyline geometry in a new layer under Geometry Imporst and compute a 25km buffer around that polyling, add it to the Map
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Compute and print area in km2 and perimeter in km for "polygon" geometry
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Compute and visualize centroids for "polygon" goemetry collection, print its coordinates in web mercator projection (EPSG:3857)
 * 
 * Tip: check ee.Geometry under Docs tab, which method should be used to convert geometry to web mercator projection?
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}

exercise1()

exercise2()

exercise3()


































/***
 * Task: Draw a new polyline geometry in a new layer under Geometry Imporst and compute a 25km buffer around that polyling, add it to the Map
 */
function solution1() {
  var line = ee.Geometry(polylines.geometries().get(0)) // Note: you need to use your new geometry here instead of the first one from polylines
  
  var buffer = line.buffer(25000)
  Map.addLayer(buffer, { color: 'white' }, 'buffer around polyline')
}

/***
 * Task: Compute and print area in km2 and perimeter in km for "polygon" geometry
 */
function solution2() {
  var area = polygon.area().divide(1000000)
  print('Area [km2]: ', area)

  var perimeter = polygon.perimeter().divide(1000)
  print('Perimeter [km]: ', perimeter)
}

/***
 * Task: Compute and visualize centroids for "polygon" goemetry collection, print its coordinates in web mercator projection (EPSG:3857)
 * 
 * Tip: check ee.Geometry under Docs tab, which method should be used to convert geometry to web mercator projection?
 */
function solution3() {
  // compute centroid
  var centroid = polygon.centroid()
  Map.addLayer(centroid, {}, 'centroid')
  
  // transform coordinates from EPSG:4326 (GEO) to EPSG:3857 (Web Mercator)
  var coords = centroid.transform('EPSG:3857')
  print('Centroid coordinates in Web Mercator projection: ', coords)
}

