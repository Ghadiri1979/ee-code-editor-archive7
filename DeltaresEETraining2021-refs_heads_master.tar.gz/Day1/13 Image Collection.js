/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = /* color: #d63000 */ee.Geometry.Point([0.2713683857984428, 49.44034117742865]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// Image Collections in Earth Engine is simply a way to combine multiple images into larger containers to simplify access
print('https://developers.google.com/earth-engine/guides/ic_creating')


// Create arbitrary constant images.
var constant1 = ee.Image(1);
var constant2 = ee.Image(2);

// Create a collection by giving a list to the constructor.
var collectionFromConstructor = ee.ImageCollection([constant1, constant2]);
print('collectionFromConstructor: ', collectionFromConstructor);



// Now let's add first 100 images acquired by Sentinel-2
var images = ee.ImageCollection('COPERNICUS/S2').limit(100) // Collection
Map.addLayer(images, { min: 500, max: 5000, bands: ['B12', 'B8', 'B3']}, 'Sentinel-2 first 100 images')

// Show properties of the first image
var image = images.first()  // Image
print(image)

/***
 * Task: Read and copy/paste and run examples from the link provided above
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
  
  // NOTE: no solution is provided for this exercise
}

/***
 * Task: Search for image collection "USGS Landsat 8 Collection 1 Tier 1 and Real-Time data TOA Reflectance" in Data Catalog and import
 * Task: Drop a pin using Geometry Tools and print a chart using ui.Chart.image.series() for bands B12 (swir), B8 (nir), B3 (green)
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE

}

exercise1()

exercise2()

















































/***
 * Task: Read and copy/paste and run examples from the link provided above
 */
function solution1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Search for image collection "USGS Landsat 8 Collection 1 Tier 1 and Real-Time data TOA Reflectance" in Data Catalog and import
 * Task: Drop a pin using Geometry Tools and print a chart using ui.Chart.image.series() for bands B12 (swir), B8 (nir), B3 (green)
 */
function solution2() {
  // ... TYPE YOUR SOLUTION HERE

  var images = ee.ImageCollection("LANDSAT/LC08/C01/T1_RT_TOA")
  images = images.select(['B6', 'B5', 'B3'])
  
  
  // this point has to be added manually instead of hardcoding here
  var point = ee.Geometry.Point([0.26283, 49.44386])
  Map.addLayer(point)
  Map.centerObject(point, 15)
  
  print(ui.Chart.image.series({ 
    imageCollection: images, 
    region: geometry, 
    scale: 10
  }))
}
