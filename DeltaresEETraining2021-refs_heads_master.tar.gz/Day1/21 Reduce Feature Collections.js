// From exercise 22: Free Flowing Rivers (WWF- HydroSHEDS)
var rivers = ee.FeatureCollection("WWF/HydroSHEDS/v1/FreeFlowingRivers")
print(rivers.first())

Map.addLayer(rivers.filter(ee.Filter.gt('DIS_AV_CMS', 10)).style({color: '0000ff', width: 3} ))
Map.addLayer(rivers.filter(ee.Filter.lt('DIS_AV_CMS', 10)).style({color: '0000ff', width: 1} ))

/***
 * Task: Compute the mean value for 'DIS_AV_CMS' property of the above dataset for France
 * User Guide: https://developers.google.com/earth-engine/guides/feature_collection_reducing
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Chart the 'DIS_AV_CMS' data for France as a histogram
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Compute 50% percentiles of the whole rivers dataset with the DIS_AV_CMS > 10
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
  
  var largerRivers = rivers.filter(ee.Filter.gt('DIS_AV_CMS', 10))
  var percentiles = largerRivers.reduceColumns({ reducer: ee.Reducer.percentile([50]), selectors: ['DIS_AV_CMS'] })
  print('50% (median) of DIS_AV_CMS', percentiles)
}



exercise1()

exercise2()

exercise3()




































/***
 * Task: Compute the mean value for 'DIS_AV_CMS' property of the above dataset for France
 * User Guide: https://developers.google.com/earth-engine/guides/feature_collection_reducing
 */
function solution1() {
  // Dataset: https://developers.google.com/earth-engine/datasets/catalog/WWF_HydroSHEDS_v1_FreeFlowingRivers
  var fr = ee.FeatureCollection("WWF/HydroSHEDS/v1/FreeFlowingRivers")
              .filter(ee.Filter.eq('COUNTRY', 'France'));
  var mean = fr.reduceColumns({reducer: ee.Reducer.mean(),selectors: ['DIS_AV_CMS']});
  print(mean);
  
  // Alternate way
  var mean2 = fr.aggregate_mean('DIS_AV_CMS')
  print(mean2)
}

/***
 * Task: Chart the 'DIS_AV_CMS' data for France as a histogram
 */
function solution2() {
  var chart = ui.Chart.feature.histogram({features: rivers, property: 'DIS_AV_CMS',
                                          maxBuckets: 100})
  print(chart)

  // Alternative
  print(rivers.reduceColumns({reducer: ee.Reducer.histogram(100), selectors: ['DIS_AV_CMS']}))
}

/***
 * Task: Compute 50% percentiles of the whole rivers dataset with the DIS_AV_CMS > 10
 */
function solution3() {
  // ... TYPE YOUR SOLUTION HERE
  
  var largerRivers = rivers.filter(ee.Filter.gt('DIS_AV_CMS', 10))
  var percentiles = largerRivers.reduceColumns({ reducer: ee.Reducer.percentile([50]), selectors: ['DIS_AV_CMS'] })
  print('50% (median) of DIS_AV_CMS', percentiles)
}

