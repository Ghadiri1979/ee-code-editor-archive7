// Much like python, in JavaScript (JS), you can print your output
// using the print() function, such as in Line 4.

// Notice that running the code does not print out what all the extra
// stuff we wrote. '//' is how you comment out lines of code

print('Hello World!')   // To run your script, press CTRL+ENTER





