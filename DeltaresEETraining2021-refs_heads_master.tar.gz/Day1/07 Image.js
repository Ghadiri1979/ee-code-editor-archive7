// Create an image containing the same pixel values.

var image1 = ee.Image.constant(0) // We created an image filled with zeros.
Map.addLayer(image1, {}, 'image1', false)
print('image1: ', image1)

// When we type a  list of numbers in constant(), we define individual bands.
// Each band within an image can carry different types of information.
var image2 = ee.Image.constant([0, 1]) // Now we have two bands
Map.addLayer(image2, {}, 'image2', false)
print('image2: ', image2)

// Inspect the image metadata. What are the bands called?
// Depending on the data you produce, you might want to name it something else.
// Try renaming them below.
var image3 = ee.Image.constant([0, 1]).rename(['band1', 'band2'])
print('image3: ', image3)
Map.addLayer(image3, {}, 'image3', false)


/***
 * Task: Combine image1 and image2 into a single image consisting of two bands. Add the resulting image to the Map with show=false and inspect.
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE

  var image1 = ee.Image.constant(0) 
  var image2 = ee.Image.constant(2)

  var image = ee.Image([image1, image2])
  print('exercice1 image: ', image)
  
  Map.addLayer(image, {}, 'exercise1 image', false)
}

/***
 * Task: Import SRTM elevation image, compute hillshade and add it to the Map.
 * 
 * Tip: Search for hillshade in the Docs tab
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE

  
  // add a single-band image
  var srtm = ee.Image("USGS/SRTMGL1_003");
  Map.addLayer(srtm, {}, 'exercice 2, SRTM image', false)

  var hs = ee.Terrain.hillshade(srtm)
  Map.addLayer(hs, {}, 'exercice 2, SRTM hillshade')
}

exercise1()

exercise2()

