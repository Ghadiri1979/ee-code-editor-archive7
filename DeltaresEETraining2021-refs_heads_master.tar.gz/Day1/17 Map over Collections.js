/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = 
    /* color: #d63000 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[6.830695189426166, 46.38238204783006],
          [6.830695189426166, 46.36295783500723],
          [6.853354491183978, 46.36295783500723],
          [6.853354491183978, 46.38238204783006]]], null, false);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var l8 = ee.ImageCollection("LANDSAT/LC08/C01/T2_TOA").filterBounds(Map.getBounds(true));
Map.addLayer(l8)


/***
 * Task: Make a simple function that adds a number, and try mapping it over a list of numbers
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Try mapping a simple band math operation over a collection of images (l8).
 *        Chart your results in a histogram (optional).
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Calculate the area over a feature collection. Search for the WWF HydroSHEDS Basins Level 12
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()

exercise3()



























































// Solutions

function solution1() {
  var numbers = [1, 3, 7, 8]

  function addTwo(value) {
    return ee.Number(value).add(2)
  }
  print(numbers.map(addTwo))
}

function solution2() {
  var add = function (image) {
    return image.select('B2').add(image.select('B4'))
  };
  print(l8.map(add));
  print(ui.Chart.image.histogram({
    image: l8.map(add).first(),
    region: ee.Geometry(Map.getBounds(true)),
    scale: 100,
    maxBuckets: 100
  }));
}

function solution3() {
  var basins = ee.FeatureCollection("USGS/WBD/2017/HUC06");
  print(basins.first())
  var area = function (image) {
    return image.set('AREA', image.geometry().area())
  }
  print(basins.map(area).aggregate_array('AREA'))
}

solution3()