/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var images = ee.ImageCollection("COPERNICUS/S2"),
    geometry = /* color: #ffc82d */ee.Geometry.Point([-1.677876737339783, 47.98819203922952]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var scale = Map.getScale()

images = images
  .filterBounds(geometry)
  .filterDate('2020-01-01', '2020-12-01')
  .select(['B12', 'B8', 'B3'])
  // .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))

print('Number of images after filtering: ', images.size())  
  
Map.addLayer(images, { min: 300, max: 3500 }, 'images (mosaic)')


/***
 * Task: Compute a median image from images and add to the map, use (min, max) visualization parameters equal to  (300, 3500)
 * Task: Print values for a given point "geometry"
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Now do the same for 20% percentile for the same image collection and add it to the map with the same (min, max) visualization parameters equal to (300, 3500)
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Show a chart of time series for the above image collection at a "geometry" point.
 * Task: Show histogram of values for band B12 for that time series
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}

exercise1()

exercise2()

exercise3()



































/***
 * Task: Compute a median image from images and add to the map, use (min, max) visualization parameters equal to  (300, 3500)
 * Task: Print values for a given point "geometry"
 */
function solution1() {
  // ... TYPE YOUR SOLUTION HERE
  
  var median = images.median()
  Map.addLayer(median, { min: 300, max: 3500 }, 'median')
  
  // query a single value from the image
  var value = median.reduceRegion(ee.Reducer.first(), geometry, scale)
  print(value)
}

/***
 * Task: Now do the same for 20% percentile for the same image collection and add it to the map with the same (min, max) visualization parameters equal to (300, 3500)
 */
function solution2() {
  // ... TYPE YOUR SOLUTION HERE

  var p20 = images.reduce(ee.Reducer.percentile([20]))
  Map.addLayer(p20, { min: 300, max: 3500 }, '20%')
}

/***
 * Task: Show a chart of time series for the above image collection at a "geometry" point.
 * Task: Show histogram of values for band B12 for that time series
 */
function solution3() {
  // ... TYPE YOUR SOLUTION HERE
  
  // qeury using chart
  print(ui.Chart.image.series(images, geometry, ee.Reducer.first(), scale))

  // for every image, compute value by using image reducer  
  var features = images.map(function(image) {
    return image.set(image.reduceRegion(ee.Reducer.first(), geometry, scale))
  })
  
  // show historgram
  print(ui.Chart.feature.histogram(features, 'B12', 50))
}
