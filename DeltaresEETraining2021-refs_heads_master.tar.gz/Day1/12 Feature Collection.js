// Let's contruct a feature collection manually
var features = ee.FeatureCollection([
  ee.Feature(ee.Geometry.Point(0, 0), { p1: 1, p2: 1 }),
  ee.Feature(ee.Geometry.Point(0, 1), { p1: 3, p2: 2 }),
  ee.Feature(ee.Geometry.Point(1, 0), { p1: 5, p2: 1 })
])

print(features)

// Add feature collection to the map
Map.addLayer(features, {}, 'coded features')
Map.centerObject(features)

// We can use Chart to visualize feature properties
print(ui.Chart.feature.byFeature(features, 'p1', 'p2'))


// Earth Engine also has a number of pre-defined feature collections (like large shapefiles) which can be explored in the Data Catalog

/***
 * Task: Search for "hydrosheds free flowing rivers" feature collection and add it to the Map. 
 * Task: Use ee.FeatureCollection.style() method to adjust styles, set color to blue and width to 1.
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()








































/***
 * Task: Search for "hydrosheds free flowing rivers" feature collection and add it to the Map. 
 * Task: Use ee.FeatureCollection.style() method to adjust styles, set color to blue and width to 1.
 */
function solution1() {
  // ... TYPE YOUR SOLUTION HERE

  var rivers = ee.FeatureCollection("WWF/HydroSHEDS/v1/FreeFlowingRivers").filterBounds(Map.getBounds(true))

  Map.addLayer(rivers.style({ color: 'blue', width: 1 }), {}, 'rivers')
}

