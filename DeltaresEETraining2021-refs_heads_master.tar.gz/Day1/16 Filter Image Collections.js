/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = /* color: #98ff00 */ee.Geometry.Point([1.1364870454574527, 42.723391347883485]),
    images = ee.ImageCollection("COPERNICUS/S2");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// Previously, you loaded a single image. In this exercise, let's try loading
// using the image collection.

// You don't necessarily want to analyse all the images within a collection too
// What part of the collection can you filter out?
// .filterBounds() --> filter based on intersection with a defined boundary
// .filterDate() --> filter based on different time periods (eg. wet season vs dry season)
// .filterMetadata --> filter based on specific metadata information

// Try filling in a time period yourself. Have it in a string in YYYY-MM-DD format.

var filtered = images
      .filterBounds(geometry)
      .filterDate('2019-01-01', '2021-01-01')
      .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 30)

print(filtered.size())

print(ui.Chart.feature.histogram({
  features: filtered, 
  property: 'MEAN_SOLAR_ZENITH_ANGLE'
}))

/***
 * Task: Visualize your map as a true-colour image, use .mean() at the end. Use 300-3500 as min/max values
 * 
 * Tip: A true-colour image represents what we would see within the visible wavelength,
 *    i.e. an RGB image (RedGreenBlue). Which Landsat 8 bands correspond to RGB?
 */
function exercise1() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Add an additional filter to the variable 'filtered', and select only images
 *       within the collection where the sun zenith is more than 50 degrees.
 * 
 * Tip: Try first printing the image collection and inspecting its metadata carefully.
 */
function exercise2() {
  // ... TYPE YOUR SOLUTION HERE
}

/***
 * Task: Try the same as exercise2, but with sun zenith < 50
 */
function exercise3() {
  // ... TYPE YOUR SOLUTION HERE
}


exercise1()

exercise2()

exercise3()
























































































/***
 * Task: Visualize your map as a true-colour image, use .mean() at the end. Use 300-3500 as min/max values
 * 
 * Tip: A true-colour image represents what we would see within the visible wavelength,
 *    i.e. an RGB image (RedGreenBlue). Which Landsat 8 bands correspond to RGB?
 */
function solution1() {
  // ... TYPE YOUR SOLUTION HERE
  
  Map.addLayer(filtered.mean(), { min: 300, max: 3500, bands: ['B4', 'B3', 'B2'] }, 'RGB');
}

/***
 * Task: Add an additional filter to the variable 'filtered', and select only images
 *       within the collection where the sun zenith is more than 50 degrees.
 * 
 * Tip: Try first printing the image collection and inspecting its metadata carefully.
 */
function solution2() {
  // ... TYPE YOUR SOLUTION HERE

  var filteredGt50 = filtered
        .filterMetadata('MEAN_SOLAR_ZENITH_ANGLE', 'greater_than', 50)
        
  print(filteredGt50.size())        

  Map.addLayer(filteredGt50.mean(), { min: 300, max: 3500, bands: ['B4', 'B3', 'B2'] }, 'RGB, elevation > 50');
}

/***
 * Task: Try the same as exercise2, but with sun zenith < 50
 */
function solution3() {
  // ... TYPE YOUR SOLUTION HERE

  var filteredLt30 = filtered.filter(ee.Filter.lt('MEAN_SOLAR_ZENITH_ANGLE', 50))
        
  print(filteredLt30.size())        

  Map.addLayer(filteredLt30.mean(), { min: 300, max: 3500, bands: ['B4', 'B3', 'B2'] }, 'RGB, elevation < 50');
}
